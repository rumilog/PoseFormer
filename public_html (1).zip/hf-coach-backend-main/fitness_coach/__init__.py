"""
Fitness Coach Module
Scoring system for comparing user exercise performance to reference videos
"""

__version__ = "0.1.0"

